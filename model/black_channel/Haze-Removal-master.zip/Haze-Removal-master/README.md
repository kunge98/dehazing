# Haze-Removal
何恺明经典去雾算法《Single Image Haze Removal Using Dark Channel Prior》的Python实现，其中guided filter参看[这里](https://github.com/nan86150/GuidedFilter)的一个实现

## 实例
[http://tools.pfchai.com](http://tools.pfchai.com)是基于该项目的一个在线版图像去雾应用

## 文件说明

 - HazeRemoval.py 最简单的一个实现，没有使用Guided Filter
 - HazeRemovalWidthGuided.py  使用Guided Filter滤波的图像去雾
